#include<stdio.h>
#define MAX 20
#define INF 9999

int f(int p[],int i){while(p[i]){i=p[i];}return i;}
void u(int p[],int i,int j){p[j]=i;}

int main(){
    int c[MAX][MAX],p[MAX]={0},n,u1,v1,min,mc=0,e=0;

    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("\nEnter the cost adjacency matrix:\n");
    for(int i=1;i<=n;i++){for(int j=1;j<=n;j++){scanf("%d",&c[i][j]);if(!c[i][j])c[i][j]=INF;}}

    printf("\nEdges in Minimum Spanning Tree:\n");

    while(e<n-1){min=INF;for(int i=1;i<=n;i++){for(int j=1;j<=n;j++){if(c[i][j]<min){min=c[i][j];u1=i;v1=j;}}}int a=f(p,u1),b=f(p,v1);if(a!=b){printf("%d edge (%d,%d) = %d\n",e+1,u1,v1,min);mc+=min;e++;u(p,a,b);}c[u1][v1]=c[v1][u1]=INF;}

    printf("\nMinimum Cost = %d\n",mc);
}
