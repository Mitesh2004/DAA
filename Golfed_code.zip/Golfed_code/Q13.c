#include<stdio.h>
#define MAX 20

int q[MAX],f=-1,r=-1;

void bfs(int g[][MAX],int n,int s){int v[MAX]={0};q[++r]=s;v[s]=1;printf("\nBFS Traversal: ");while(f!=r){int x=q[++f];printf("%d ",x);for(int i=1;i<=n;i++){if(g[x][i]&&!v[i]){q[++r]=i,v[i]=1;}}}}

void dfs(int g[][MAX],int v[],int x,int n){printf("%d ",x);v[x]=1;for(int i=1;i<=n;i++){if(g[x][i]&&!v[i]){dfs(g,v,i,n);}}}

int main(){
    int g[MAX][MAX],v[MAX]={0},n,s;

    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("\nEnter adjacency matrix:\n");
    for(int i=1;i<=n;i++){for(int j=1;j<=n;j++){scanf("%d",&g[i][j]);}}

    printf("\nEnter starting vertex: ");
    scanf("%d",&s);

    printf("\nDFS Traversal: ");
    dfs(g,v,s,n);

    bfs(g,n,s);
    printf("\n");
}
