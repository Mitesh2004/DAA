#include<stdio.h>
#define MAX 20
#define INF 9999

int sm(int f[],int i,int j){int s=0;for(int k=i;k<=j;k++){s+=f[k];}return s;}

int ob(int k[],int f[],int n){int c[MAX][MAX];for(int i=0;i<n;i++){c[i][i]=f[i];}for(int L=2;L<=n;L++){for(int i=0;i<=n-L;i++){int j=i+L-1,fs=sm(f,i,j);c[i][j]=INF;for(int r=i;r<=j;r++){int x=fs;if(r>i)x+=c[i][r-1];if(r<j)x+=c[r+1][j];if(x<c[i][j])c[i][j]=x;}}}return c[0][n-1];}

int main(){
    int k[MAX],f[MAX],n;

    printf("Enter number of keys: ");
    scanf("%d",&n);

    printf("Enter keys:\n");
    for(int i=0;i<n;i++)scanf("%d",&k[i]);

    printf("Enter frequencies:\n");
    for(int i=0;i<n;i++)scanf("%d",&f[i]);

    int cost=ob(k,f,n);

    printf("\nOptimal Binary Search Tree Cost = %d\n",cost);
    printf("\nBest Case Complexity  = O(n^2)");
    printf("\nWorst Case Complexity = O(n^3)\n");
}
