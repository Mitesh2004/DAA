#include<stdio.h>
#include<time.h>
#define MAX 1000
#define M 1000

void s(int a[],int n){for(int i=0;i<n-1;i++){int m=i;for(int j=i+1;j<n;j++){if(a[j]<a[m])m=j;}int t=a[i];a[i]=a[m];a[m]=t;}}
void i(int a[],int n){for(int x=1;x<n;x++){int k=a[x],j=x-1;while(j>=0&&a[j]>k){a[j+1]=a[j];j--;}a[j+1]=k;}}
void hfy(int a[],int n,int i){int l=2*i+1,r=2*i+2,m=i;if(l<n&&a[l]>a[m])m=l;if(r<n&&a[r]>a[m])m=r;if(m!=i){int t=a[i];a[i]=a[m];a[m]=t;hfy(a,n,m);}}
void h(int a[],int n){for(int i=n/2-1;i>=0;i--){hfy(a,n,i);}for(int i=n-1;i>0;i--){int t=a[0];a[0]=a[i];a[i]=t;hfy(a,i,0);}}
int mx(int a[],int n){int m=a[0];for(int i=1;i<n;i++){if(a[i]>m)m=a[i];}return m;}
void cs(int a[],int n,int e){int o[M],c[10]={0};for(int i=0;i<n;i++)c[(a[i]/e)%10]++;for(int i=1;i<10;i++)c[i]+=c[i-1];for(int i=n-1;i>=0;i--)o[--c[(a[i]/e)%10]]=a[i];for(int i=0;i<n;i++)a[i]=o[i];}
void r(int a[],int n){for(int e=1,m=mx(a,n);m/e;e*=10){cs(a,n,e);}}
void cp(int a[],int b[],int n){for(int i=0;i<n;i++){b[i]=a[i];}}
void p(int a[],int n){for(int i=0;i<n;i++){printf("%d ",a[i]);}puts("");}

int main(){
	int a[MAX],t[MAX],n;clock_t s1,e;double d;

	printf("Enter number of elements: ");
	scanf("%d",&n);
	printf("Enter numbers:\n");
	for(int i=0;i<n;i++)scanf("%d",&a[i]);

	cp(a,t,n);s1=clock();s(t,n);e=clock();
	printf("\nSelection Sort Output:\n");p(t,n);
	printf("Selection Sort Time = %f",(d=(double)(e-s1)/CLOCKS_PER_SEC));

	cp(a,t,n);s1=clock();i(t,n);e=clock();
	printf("\nInsertion Sort Output:\n");p(t,n);
	printf("Insertion Sort Time = %f",(d=(double)(e-s1)/CLOCKS_PER_SEC));

	cp(a,t,n);s1=clock();h(t,n);e=clock();
	printf("\nHeap Sort Output:\n");p(t,n);
	printf("Heap Sort Time = %f",(d=(double)(e-s1)/CLOCKS_PER_SEC));

	cp(a,t,n);s1=clock();r(t,n);e=clock();
	printf("\nRadix Sort Output:\n");p(t,n);
	printf("Radix Sort Time = %f\n",(d=(double)(e-s1)/CLOCKS_PER_SEC));
}
