#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 10000

void sw(int*a,int*b){int t=*a;*a=*b;*b=t;}
int pt(int a[],int l,int h){int p=a[h],i=l-1;for(int j=l;j<h;j++){if(a[j]<p){sw(&a[++i],&a[j]);}}sw(&a[i+1],&a[h]);return i+1;}
void qs(int a[],int l,int h){if(l<h){int p=pt(a,l,h);qs(a,l,p-1);qs(a,p+1,h);}}
void p(int a[],int n){for(int i=0;i<n;i++){printf("%d ",a[i]);}puts("");}

int main(){
    FILE *f;int a[MAX],n;clock_t s,e;double t;

    f=fopen("input.txt","r");
    fscanf(f,"%d",&n);
    for(int i=0;i<n;i++)fscanf(f,"%d",&a[i]);
    fclose(f);

    printf("Elements read from file:\n");p(a,n);

    s=clock();qs(a,0,n-1);e=clock();

    printf("\nSorted Elements (Quick Sort):\n");p(a,n);
    printf("\nTime taken to sort %d elements = %f seconds\n",
           n,(t=(double)(e-s)/CLOCKS_PER_SEC));
}
