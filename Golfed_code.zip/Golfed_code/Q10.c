#include<stdio.h>
#include<stdlib.h>
#define MAX 100

struct N{char d;int f;struct N*l,*r;};

struct N* nn(char d,int f){struct N*t=malloc(sizeof(struct N));t->d=d;t->f=f;t->l=t->r=NULL;return t;}

void sw(struct N**a,struct N**b){struct N*t=*a;*a=*b;*b=t;}

void s(struct N* a[],int n){for(int i=0;i<n-1;i++){for(int j=0;j<n-i-1;j++){if(a[j]->f>a[j+1]->f){sw(&a[j],&a[j+1]);}}}}

void pc(struct N*r,int c[],int t){if(r->l){c[t]=0;pc(r->l,c,t+1);}if(r->r){c[t]=1;pc(r->r,c,t+1);}if(!r->l&&!r->r){printf("%c: ",r->d);for(int i=0;i<t;i++){printf("%d",c[i]);}printf("\n");}}

void hf(char d[],int f[],int n){struct N* a[MAX];for(int i=0;i<n;i++){a[i]=nn(d[i],f[i]);}int sz=n;while(sz>1){s(a,sz);struct N*l=a[0],*r=a[1];struct N*t=nn('$',l->f+r->f);t->l=l;t->r=r;a[0]=t;for(int i=1;i<sz-1;i++){a[i]=a[i+1];}sz--;}int c[MAX];printf("\nHuffman Codes:\n");pc(a[0],c,0);}

int main(){
    char d[MAX];int f[MAX],n;

    printf("Enter number of characters: ");
    scanf("%d",&n);

    printf("Enter characters:\n");
    for(int i=0;i<n;i++)scanf(" %c",&d[i]);

    printf("Enter frequencies:\n");
    for(int i=0;i<n;i++)scanf("%d",&f[i]);

    hf(d,f,n);

    printf("\nBest Case Complexity  = O(n log n)");
    printf("\nWorst Case Complexity = O(n log n)\n");
}
