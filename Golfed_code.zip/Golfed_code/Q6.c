#include<stdio.h>
#define MAX 20
#define INF 9999

void pr(int c[][MAX],int n){int v[MAX]={0},min,mc=0,u=1,w=1,e=0;v[1]=1;printf("\nEdges in Minimum Spanning Tree:\n");while(e<n-1){min=INF;for(int i=1;i<=n;i++){if(v[i]){for(int j=1;j<=n;j++){if(!v[j]&&c[i][j]<min){min=c[i][j];u=i;w=j;}}}} printf("%d edge (%d,%d) = %d\n",e+1,u,w,min); mc+=min;e++;v[w]=1;} printf("\nMinimum Cost = %d\n",mc);}

int main(){
    int c[MAX][MAX],n;

    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("\nEnter cost adjacency matrix:\n");
    for(int i=1;i<=n;i++){for(int j=1;j<=n;j++){scanf("%d",&c[i][j]);if(!c[i][j]){c[i][j]=INF;}}}
    pr(c,n);
}
