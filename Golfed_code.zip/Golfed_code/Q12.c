#include<stdio.h>
#include<string.h>
#define MAX 100

int mx(int a,int b){return a>b?a:b;}

int lcs(char X[],char Y[]){int m=strlen(X),n=strlen(Y),L[MAX][MAX];for(int i=0;i<=m;i++){L[i][0]=0;}for(int j=0;j<=n;j++){L[0][j]=0;}for(int i=1;i<=m;i++){for(int j=1;j<=n;j++){L[i][j]=(X[i-1]==Y[j-1])?L[i-1][j-1]+1:mx(L[i-1][j],L[i][j-1]);}}return L[m][n];}

int main(){
    char X[MAX],Y[MAX];

    printf("Enter first string: ");
    scanf("%s",X);

    printf("Enter second string: ");
    scanf("%s",Y);

    int l=lcs(X,Y);

    printf("\nLength of Longest Common Subsequence = %d\n",l);
}
