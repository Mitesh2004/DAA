#include<stdio.h>
#define MAX 20

struct it{int w,p;float r;};

void s(struct it a[],int n){for(int i=0;i<n-1;i++){for(int j=0;j<n-i-1;j++){if(a[j].r<a[j+1].r){struct it t=a[j];a[j]=a[j+1];a[j+1]=t;}}}}

void k(struct it a[],int n,int c){float tp=0;for(int i=0;i<n;i++){if(a[i].w<=c){c-=a[i].w;tp+=a[i].p;printf("Item %d taken completely\n",i+1);}else{float f=(float)c/a[i].w;tp+=a[i].p*f;printf("Item %d taken fractionally (%.2f part)\n",i+1,f);break;}}printf("\nMaximum Profit = %.2f\n",tp);}

int main(){
    struct it a[MAX];int n,c;

    printf("Enter number of items: ");
    scanf("%d",&n);

    for(int i=0;i<n;i++){printf("Enter profit and weight of item %d: ",i+1);scanf("%d %d",&a[i].p,&a[i].w);a[i].r=(float)a[i].p/a[i].w;}

    printf("Enter knapsack capacity: ");
    scanf("%d",&c);

    s(a,n);
    k(a,n,c);
}
