#include<stdio.h>
#define MAX 20
#define INF 999999

int mc(int p[],int n){int m[MAX][MAX];for(int i=1;i<n;i++){m[i][i]=0;}for(int L=2;L<n;L++){for(int i=1;i<n-L+1;i++){int j=i+L-1;m[i][j]=INF;for(int k=i;k<j;k++){int q=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];if(q<m[i][j]){m[i][j]=q;}}}}return m[1][n-1];}

int main(){
    int p[MAX],n;

    printf("Enter number of matrices: ");
    scanf("%d",&n);

    printf("Enter dimensions array (size %d):\n",n+1);
    for(int i=0;i<=n;i++)scanf("%d",&p[i]);

    int r=mc(p,n+1);

    printf("\nMinimum number of multiplications = %d\n",r);
}
