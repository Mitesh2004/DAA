#include<stdio.h>
#define MAX 20
#define INF 9999

void dj(int c[][MAX],int n,int s){int d[MAX],v[MAX]={0},u,min;for(int i=1;i<=n;i++){d[i]=c[s][i];}d[s]=0;v[s]=1;for(int i=1;i<n;i++){min=INF;for(int j=1;j<=n;j++){if(!v[j]&&d[j]<min){min=d[j];u=j;}}v[u]=1;for(int j=1;j<=n;j++){if(!v[j]&&d[u]+c[u][j]<d[j]){d[j]=d[u]+c[u][j];}}}printf("\nShortest distances from vertex %d:\n",s);for(int i=1;i<=n;i++){printf("Distance to vertex %d = %d\n",i,d[i]);}}

int main(){
    int c[MAX][MAX],n,s;

    printf("Enter number of vertices: ");
    scanf("%d",&n);

    printf("\nEnter cost adjacency matrix:\n");
    for(int i=1;i<=n;i++){for(int j=1;j<=n;j++){scanf("%d",&c[i][j]);if(!c[i][j]&&i!=j){c[i][j]=INF;}}}

    printf("\nEnter source vertex: ");
    scanf("%d",&s);

    dj(c,n,s);
}
