#include<stdio.h>
#include<stdlib.h> 
#include<time.h>
int main(){
    FILE *f;int n;
    printf("Enter number of elements to generate: ");
    scanf("%d",&n);
    f=fopen("input.txt","w");
    srand(time(0));
    fprintf(f,"%d\n",n);
    for(int i=0;i<n;i++)fprintf(f,"%d ",rand()%1000);
    fclose(f);
    printf("\ninput.txt file generated successfully with %d numbers.\n",n);
}
