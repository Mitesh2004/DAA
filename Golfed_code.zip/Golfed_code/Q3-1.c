#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 10000

void mg(int a[],int l,int m,int r){int n1=m-l+1,n2=r-m,L[5000],R[5000];for(int i=0;i<n1;i++){L[i]=a[l+i];}for(int j=0;j<n2;j++){R[j]=a[m+1+j];}int i=0,j=0,k=l;while(i<n1&&j<n2){a[k++]=(L[i]<=R[j])?L[i++]:R[j++];}while(i<n1){a[k++]=L[i++];}while(j<n2){a[k++]=R[j++];}}

void ms(int a[],int l,int r){if(l<r){int m=(l+r)/2;ms(a,l,m);ms(a,m+1,r);mg(a,l,m,r);}}

void p(int a[],int n){for(int i=0;i<n;i++){printf("%d ",a[i]);}puts("");}

int main(){
    FILE *f;int a[MAX],n;clock_t s,e;double t;

    f=fopen("input.txt","r");
    fscanf(f,"%d",&n);
    for(int i=0;i<n;i++)fscanf(f,"%d",&a[i]);
    fclose(f);

    printf("Elements read from file:\n");p(a,n);

    s=clock();ms(a,0,n-1);e=clock();

    printf("\nSorted Elements (Merge Sort):\n");p(a,n);
    printf("\nTime taken to sort %d elements = %f seconds\n",
           n,(t=(double)(e-s)/CLOCKS_PER_SEC));
}
